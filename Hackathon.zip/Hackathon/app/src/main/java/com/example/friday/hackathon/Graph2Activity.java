package com.example.friday.hackathon;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.BubbleChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.charts.ScatterChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Graph2Activity extends AppCompatActivity   {
    String[] graph;
    String xval[];
    float yval[], zval[],val[], aval[];
    private LineChart lc;
    private BarChart brc;
    private ScatterChart sc;
    private BubbleChart bc;
    private PieChart pc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph2);

        lc=(LineChart)findViewById(R.id.line_chart);
        brc=(BarChart)findViewById(R.id.bar_chart);
        //sc=(ScatterChart)findViewById(R.id.scattered_chart);
        //bc=(BubbleChart)findViewById(R.id.bubble_chart);
        pc=(PieChart)findViewById(R.id.pie_chart);

        String lightApi = "https://api.thingspeak.com/channels/699325/feeds.json?api_key=52VZZEUFUHMWUOE6?results=2";
        RequestQueue rq= Volley.newRequestQueue(this);
        JsonObjectRequest jor =new JsonObjectRequest(Request.Method.GET, lightApi, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            JSONArray ja = response.getJSONArray("feeds");
                            yval=new float[ja.length()];
                            xval=new String[ja.length()];
                            zval=new float[ja.length()];
                            val=new float[ja.length()];
                            aval=new float[ja.length()];
                            for(int i=0; i<ja.length();i++){
                                JSONObject jo = ja.getJSONObject(i);
                                String hello=jo.getString("field1").trim();
                                String hello1=jo.getString("field2").trim();
                                String hello2=jo.getString("field3").trim();
                                String hello3=jo.getString("field4").trim();
                                if(hello.equalsIgnoreCase("null"))
                                {
                                    yval[i]=0;
                                }
                                else
                                    yval[i]=Float.parseFloat(hello);

                                if(hello1.equalsIgnoreCase("null"))
                                {
                                    zval[i]=0;
                                }
                               else
                                    zval[i] = Float.parseFloat(hello1);

                                if(hello2.equalsIgnoreCase("null"))
                                {
                                    val[i]=0;
                                }
                                else {

                                    val[i]  = Float.parseFloat(hello2);
                                }

                                if(hello3.equalsIgnoreCase("null"))
                                {
                                    aval[i]=0;
                                }
                                else {

                                    aval[i]  = Float.parseFloat(hello3);
                                }
                                xval[i]=jo.getString("created_at");
                                Toast.makeText(getApplicationContext(),""+xval[i],Toast.LENGTH_SHORT).show();
                            }
                            drawLinechart(xval,yval);
                            drawBarchart(xval,zval);
                            //drawScatteredchart(xval,aval);
                            drawPiechart(xval,val);
                            drawBarchart(xval,aval);


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Error Code 2", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "ErrorCode 1", Toast.LENGTH_SHORT).show();
            }
        });
        rq.add(jor);
        //float yval[]={34,66,99,32,41,21,10};
        //String xval[]={"34","66","99","32","41","21","10"};
        //drawBubblechart(xval,yval);


    }

    private void drawLinechart(String xval[],float yval[]){
        lc.setDescription("Air Quality");
        ArrayList<Entry> yData=new ArrayList<>();

        for(int i=0;i< yval.length;i++)
        {
            yData.add(new Entry(yval[i],i));
        }
        ArrayList<String> xData=new ArrayList<>();
        for(int i=0;i<xval.length;i++)
        {

            xData.add(xval[i]);
        }
        LineDataSet lineDataSet=new LineDataSet(yData,"Air Quality");
        lineDataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        LineData lineData=new LineData(xData,lineDataSet);
        lineData.setValueTextSize(13f);
        lineData.setValueTextColor(Color.BLACK);

        lc.setData(lineData);
        lc.invalidate();
    }

    private void drawBarchart(String xval[],float yval[]){
        brc.setDescription("Air Quality");
        ArrayList<BarEntry> yData=new ArrayList<>();

        for(int i=0;i< yval.length;i++)
        {
            yData.add(new BarEntry(yval[i],i));
        }
        ArrayList<String> xData=new ArrayList<>();
        for(int i=0;i<xval.length;i++)
        {
            xData.add(xval[i]);
        }
        BarDataSet barDataSet=new BarDataSet(yData,"Air2 Quality");
        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        BarData barData=new BarData(xData,barDataSet);
        barData.setValueTextSize(13f);
        barData.setValueTextColor(Color.BLACK);

        brc.setData(barData);
        brc.invalidate();
    }

    /*private void drawScatteredchart(String xval[],float yval[]){
        sc.setDescription("Air Quality");
        ArrayList<Entry> yData=new ArrayList<>();

        for(int i=0;i< yval.length;i++)
        {
            yData.add(new Entry(yval[i],i));
        }
        ArrayList<String> xData=new ArrayList<>();
        for(int i=0;i<xval.length;i++)
        {
            xData.add(xval[i]);
        }
        ScatterDataSet scatterDataSet=new ScatterDataSet(yData,"Air Quality");
        scatterDataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        ScatterData scatterData=new ScatterData(xData,scatterDataSet);
        scatterData.setValueTextSize(13f);
        scatterData.setValueTextColor(Color.BLACK);

        sc.setData(scatterData);
        sc.invalidate();
    }*/

    private void drawPiechart(String xval[],float yval[]){
        pc.setDrawHoleEnabled(true);
        pc.setUsePercentValues(true);
        pc.setHoleColor(R.color.colorAccent);
        pc.setHoleRadius(7);
        pc.setTransparentCircleRadius(40);
        pc.setRotationAngle(0);

        pc.setDescription("Air Quality");
        ArrayList<Entry> yData=new ArrayList<>();

        for(int i=0;i< yval.length;i++)
        {
            yData.add(new Entry(yval[i],i));
        }
        ArrayList<String> xData=new ArrayList<>();
        for(int i=0;i<xval.length;i++)
        {
            xData.add(xval[i]);
        }
        PieDataSet pieDataSet=new PieDataSet(yData,"Air2 Quality");
        pieDataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        PieData pieData=new PieData(xData,pieDataSet);
        pieData.setValueTextSize(13f);
        pieData.setValueTextColor(Color.BLACK);

        pc.setData(pieData);
        pc.invalidate();
    }

    /*private void drawBubblechart(String xval[],float yval[]){
        bc.setDescription("Air Quality");
        ArrayList<BubbleEntry> yData=new ArrayList<>();

        for(int i=0;i< yval.length;i++)
        {
            yData.add(new BubbleEntry(yval[i],i));
        }

        ArrayList<String> xData=new ArrayList<>();
        for(int i=0;i<xval.length;i++)
        {
            xData.add(xval[i]);
        }
        BubbleDataSet bds=new BubbleDataSet(yData,"Air Quality");
        bds.setColors(ColorTemplate.COLORFUL_COLORS);

        BubbleData bubbleData=new BubbleData(xData,bds);
        bubbleData.setValueTextSize(13f);
        bubbleData.setValueTextColor(Color.BLACK);

        bc.setData(bubbleData);
        bc.invalidate();
    }*/

}
