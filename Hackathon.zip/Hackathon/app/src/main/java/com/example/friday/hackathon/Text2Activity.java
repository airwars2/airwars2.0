package com.example.friday.hackathon;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class Text2Activity extends AppCompatActivity {

    private TextView aqi;
    private TextView dis;

    public void auto(){
        final long period = 10;
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                new JSONTask().execute("https://api.thingspeak.com/channels/699325/feeds.json?api_key=52VZZEUFUHMWUOE6?results=2");
            }
        }, 0, period);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text2);
        aqi = (TextView)findViewById(R.id.mq135);
        dis = (TextView)findViewById(R.id.mq9);

        auto();

    }
    class JSONTask extends AsyncTask<String,String,String> {
        @Override
        public   String doInBackground(String... params ){
            StringBuffer buffer=new StringBuffer();
            HttpURLConnection connection=null;
            BufferedReader reader=null;
            URL url= null;

            try {
                url = new URL(params[0]);

                connection=(HttpURLConnection)url.openConnection();
                connection.connect();

                InputStream stream=connection.getInputStream();
                reader=new BufferedReader(new InputStreamReader(stream));
                String line="";
                buffer=new StringBuffer();
                while ((line=reader.readLine())!=null){
                    buffer.append(line);
                }
                String finalJson=buffer.toString();
                JSONObject parentobject=new JSONObject(finalJson);
                JSONArray parentarray=parentobject.getJSONArray("feeds");
                int i=parentarray.length()-1;

                JSONObject finalobject=  parentarray.getJSONObject(i);
                String val1=finalobject.getString("field1");
                return val1;

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);
            aqi.setText("AQI:"+result);

            String fifty = "50";
            String hundred = "100";
            String onefifty = "150";
            String twohundred = "200";
            String threehundred = "300";
            String fivehundred = "500";

           if(Integer.parseInt(result) < Integer.parseInt(fifty)) {
                dis.setText("Air Quality Descriptor: Good");
            }
            else if(Integer.parseInt(result) < Integer.parseInt(hundred)) {
                dis.setText("Air Quality Descriptor: Moderate");
            }
            else if(Integer.parseInt(result) < Integer.parseInt(onefifty)) {
                dis.setText("Air Quality Descriptor: Unhealthy for minors");
            }
            else if(Integer.parseInt(result) < Integer.parseInt(twohundred)) {
                dis.setText("Air Quality Descriptor: Unhealthy");
            }
            else if(Integer.parseInt(result) < Integer.parseInt(threehundred)) {
                dis.setText("Air Quality Descriptor: Very unhealthy");
            }
            else if(Integer.parseInt(result) < Integer.parseInt(fivehundred)) {
                dis.setText("Air Quality Descriptor: Hazardous");
            }
        }
    }
}