package com.example.friday.hackathon;

import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    ConstraintLayout c1;
    ImageView im1,im2,im3,im4;
    TextView tv1,tv2,tv3,tv4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c1=(ConstraintLayout)findViewById(R.id.c);
        im1=(ImageView)findViewById(R.id.imageView);
        im3=(ImageView)findViewById(R.id.imageView3);
        im2=(ImageView)findViewById(R.id.imageView2);
        im4=(ImageView)findViewById(R.id.imageView4);
        im1.setOnClickListener(this);
        im2.setOnClickListener(this);
        im3.setOnClickListener(this);
        im4.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onClick(View v) {

        if(v.getId()==R.id.imageView)
        {
            Intent i=new Intent(this,Graph2Activity.class);
            startActivity(i);
        }
        if(v.getId()==R.id.imageView3)
        {
            Intent i=new Intent(this,Text2Activity.class);
            startActivity(i);
        }
        if(v.getId()==R.id.imageView2)
        {
            Intent i=new Intent(this,Analyse2Activity.class);
            startActivity(i);
        }
        if(v.getId()==R.id.imageView4)
        {
            Intent i=new Intent(this,Sensor2Activity.class);
            startActivity(i);
        }
    }
}